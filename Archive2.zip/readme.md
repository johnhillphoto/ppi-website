npm run dev
npm run start

This site is to showcase images for Proof Positive Imaging.  Also, learning React and deploying via AWS Elastic Beanstalk.

Use node 6.9.4
